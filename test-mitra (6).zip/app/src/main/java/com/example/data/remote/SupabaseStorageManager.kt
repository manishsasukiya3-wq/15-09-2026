package com.example.data.remote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.UUID
import java.util.concurrent.TimeUnit

class SupabaseStorageManager(
    private val clientProvider: SupabaseClientProvider,
    private val context: Context
) {
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Reads image from [uri], resizes/compresses it, and uploads to 'question-images' bucket in Supabase.
     * Returns the permanent public URL on success.
     */
    suspend fun uploadQuestionImage(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val bytes = compressUriToJpeg(uri)
                ?: return@withContext Result.failure(Exception("Unable to decode or read selected image."))

            val rawBaseUrl = clientProvider.getEffectiveUrl().trim().trimEnd('/')
            val baseUrl = if (rawBaseUrl.startsWith("http://") || rawBaseUrl.startsWith("https://")) {
                rawBaseUrl
            } else {
                "https://$rawBaseUrl"
            }
            val key = clientProvider.getEffectiveAnonKey().trim()

            if (baseUrl.isBlank() || key.isBlank()) {
                return@withContext Result.failure(Exception("Supabase is not configured."))
            }

            val uniqueFileName = "q_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg"
            val uploadUrl = "$baseUrl/storage/v1/object/question-images/$uniqueFileName"

            val requestBody = bytes.toRequestBody("image/jpeg".toMediaTypeOrNull())
            val request = Request.Builder()
                .url(uploadUrl)
                .header("apikey", key)
                .header("Authorization", "Bearer $key")
                .header("Content-Type", "image/jpeg")
                .header("x-upsert", "true")
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBodyString = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val publicUrl = "$baseUrl/storage/v1/object/public/question-images/$uniqueFileName"
                Result.success(publicUrl)
            } else {
                val errorMsg = try {
                    val json = JSONObject(responseBodyString)
                    json.optString("message", json.optString("error", "HTTP ${response.code}"))
                } catch (_: Exception) {
                    "HTTP ${response.code}: $responseBodyString"
                }
                Result.failure(Exception("Storage upload failed ($errorMsg)"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun compressUriToJpeg(uri: Uri): ByteArray? {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val originalBitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (originalBitmap == null) return null

            // Resize if maximum dimension exceeds 1600px to optimize storage and loading speed
            val maxDimension = 1600
            val width = originalBitmap.width
            val height = originalBitmap.height
            val scaledBitmap = if (width > maxDimension || height > maxDimension) {
                val ratio = width.toFloat() / height.toFloat()
                val (targetWidth, targetHeight) = if (ratio > 1) {
                    Pair(maxDimension, (maxDimension / ratio).toInt())
                } else {
                    Pair((maxDimension * ratio).toInt(), maxDimension)
                }
                Bitmap.createScaledBitmap(originalBitmap, targetWidth, targetHeight, true)
            } else {
                originalBitmap
            }

            val baos = ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, baos)
            baos.toByteArray()
        } catch (e: Exception) {
            null
        }
    }
}
